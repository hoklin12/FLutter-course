void main() {
  // List of student scores
  List<int> scores = [45, 67, 82, 49, 51, 78, 92, 30];
  
  // Your code
  print("Input: ${scores}");
  List<int> pStudents = scores.where((scores)=> scores > 50).toList();
   print("Output: ${pStudents}");

   print("${pStudents.length} students passed ");
}